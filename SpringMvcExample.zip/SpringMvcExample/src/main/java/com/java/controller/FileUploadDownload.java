package com.java.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.tagext.TryCatchFinally;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FileUploadDownload {
	
	@RequestMapping(value = "/fileUpload", method = RequestMethod.POST)
	public String uploadFile(HttpServletRequest req,
			@RequestParam("files") MultipartFile[] uploadFile) 
					throws IllegalStateException, IOException {
		List<String> fileNames=new ArrayList<String>();
		String destination="";
		
		String directory=destination;
		Path p=Paths.get(directory);
		Files.createDirectories(p);
		
		
			if(uploadFile!=null && uploadFile.length>0) {
				
				System.out.println("files created");
				
				for (MultipartFile multiPart : uploadFile) {
					String fileName=multiPart.getOriginalFilename();
					fileNames.add(fileName);
					File imageFile=new File(destination,fileName);
					
					multiPart.transferTo(imageFile);
				}
				
		
			
		}
		return "";
		
		
		
		
		
	}

}

package com.java.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.java.model.User;

@Controller
public class LoginController {


	@RequestMapping(value = "/adminLogin", method = RequestMethod.POST)
	public String user(@Validated User user, Model model) {
		System.out.println(user.toString());
		if(user.getUserName().equalsIgnoreCase("admin") && user.getPassWord().equals("admin")) {
			System.out.println("User approved");
			model.addAttribute("userName", user.getUserName());
			return "user";
		}else {
			System.out.println("User not approved");
		}
		
		return "user";
	}
}
